package com.example.ticketlive

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        val user = EditText(this).apply { hint = "Ton @pseudo TikTok (vide = démo)"; setSingleLine() }
        val start = Button(this).apply { text = "Démarrer les tickets" }
        val stop = Button(this).apply { text = "Arrêter" }

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Autorise l’affichage par-dessus les autres applis, puis reviens", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            val i = Intent(this, OverlayService::class.java).putExtra("user", user.text.toString().trim().removePrefix("@"))
            startForegroundService(i)
        }
        stop.setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }

        col.addView(TextView(this).apply { text = "Ticket Live"; textSize = 24f })
        col.addView(user); col.addView(start); col.addView(stop)
        setContentView(col)
    }
}
