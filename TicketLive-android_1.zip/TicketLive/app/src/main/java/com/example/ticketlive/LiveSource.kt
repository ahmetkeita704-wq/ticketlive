package com.example.ticketlive

import android.os.Handler
import android.os.Looper
import org.json.JSONObject

data class LiveEvent(
    val type: String,            // "join", "follow" ou "gift"
    val name: String,
    val handle: String,
    val avatar: String? = null,  // URL de la photo de profil (affichée en couleur)
    val gift: String? = null,
    val count: Int = 1,
    val diamonds: Int = 0
) {
    fun toJson(): String = JSONObject()
        .put("type", type).put("name", name).put("handle", handle)
        .put("avatar", avatar ?: JSONObject.NULL).put("gift", gift ?: JSONObject.NULL)
        .put("count", count).put("diamonds", diamonds).toString()
}

interface LiveSource {
    fun start(onEvent: (LiveEvent) -> Unit)
    fun stop()
}

/** Faux événements toutes les 7 secondes, pour tester le ticket et la voix. */
class DemoSource : LiveSource {
    private val h = Handler(Looper.getMainLooper())
    private var on = false
    private var cb: ((LiveEvent) -> Unit)? = null
    private val people = listOf("Léa" to "lea_danse", "Karim" to "karim.93", "Mia" to "mia.lounge", "Théo" to "theoplays")
    private val tick = object : Runnable {
        override fun run() {
            if (!on) return
            val (n, u) = people.random()
            cb?.invoke(when ((0..3).random()) {
                0 -> LiveEvent("join", n, u)
                1 -> LiveEvent("follow", n, u)
                2 -> LiveEvent("gift", n, u, null, "Rose", 5, 5)
                else -> LiveEvent("gift", n, u, null, "Lion", 1, 29999)
            })
            h.postDelayed(this, 7000)
        }
    }
    override fun start(onEvent: (LiveEvent) -> Unit) { cb = onEvent; on = true; h.post(tick) }
    override fun stop() { on = false; h.removeCallbacks(tick) }
}

/**
 * La seule pièce à brancher : la réception des vrais événements du live.
 * TikTok n'a pas d'API officielle pour ça : utilise le SDK Java d'EulerStream
 * (com.eulerstream:euler-api-sdk) ou TikTokLiveJava, puis, pour chaque événement
 * (arrivée, follow, cadeau), appelle par exemple :
 *   onEvent(LiveEvent("gift", surnom, pseudo, urlPhoto, nomCadeau, nombre, diamants))
 */
class TikTokLiveSource(private val username: String) : LiveSource {
    override fun start(onEvent: (LiveEvent) -> Unit) {
        throw NotImplementedError("Source TikTok pas encore branchée pour @$username")
    }
    override fun stop() {}
}
