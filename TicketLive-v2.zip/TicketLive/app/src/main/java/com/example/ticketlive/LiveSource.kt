package com.example.ticketlive

import android.os.Handler
import android.os.Looper
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject

data class LiveEvent(
    val type: String,            // "join", "follow" ou "gift"
    val name: String,
    val handle: String,
    val avatar: String? = null,  // URL de la photo de profil (affichée en couleur)
    val gift: String? = null,
    val count: Int = 1,
    val diamonds: Int = 0
) {
    fun toJson(): String = JSONObject()
        .put("type", type).put("name", name).put("handle", handle)
        .put("avatar", avatar ?: JSONObject.NULL).put("gift", gift ?: JSONObject.NULL)
        .put("count", count).put("diamonds", diamonds).toString()
}

interface LiveSource {
    fun start(onEvent: (LiveEvent) -> Unit)
    fun stop()
}

/** État de la connexion, affiché par le bouton « Voir l'état » de l'appli. */
object Status {
    @Volatile var last: String = "Aucune connexion pour l'instant"
    @Volatile var count: Int = 0
}

/** Faux événements toutes les 7 secondes, pour tester le ticket et la voix. */
class DemoSource : LiveSource {
    private val h = Handler(Looper.getMainLooper())
    private var on = false
    private var cb: ((LiveEvent) -> Unit)? = null
    private val people = listOf("Léa" to "lea_danse", "Karim" to "karim.93", "Mia" to "mia.lounge", "Théo" to "theoplays")
    private val tick = object : Runnable {
        override fun run() {
            if (!on) return
            val (n, u) = people.random()
            cb?.invoke(when ((0..3).random()) {
                0 -> LiveEvent("join", n, u)
                1 -> LiveEvent("follow", n, u)
                2 -> LiveEvent("gift", n, u, null, "Rose", 5, 5)
                else -> LiveEvent("gift", n, u, null, "Lion", 1, 29999)
            })
            h.postDelayed(this, 7000)
        }
    }
    override fun start(onEvent: (LiveEvent) -> Unit) { cb = onEvent; on = true; h.post(tick) }
    override fun stop() { on = false; h.removeCallbacks(tick) }
}

/**
 * Vraie source : WebSocket EulerStream (wss://ws.eulerstream.com).
 * Le format exact des messages n'a pas pu être vérifié : l'analyse ci-dessous est tolérante,
 * et le bouton « Voir l'état » de l'appli affiche le dernier message brut pour l'ajuster au besoin.
 */
class TikTokLiveSource(private val username: String, private val apiKey: String) : LiveSource {
    private var ws: WebSocket? = null
    private val client = OkHttpClient()
    private var lastJoin = 0L

    override fun start(onEvent: (LiveEvent) -> Unit) {
        var url = "wss://ws.eulerstream.com?uniqueId=$username"
        if (apiKey.isNotBlank()) url += "&apiKey=$apiKey"
        Status.count = 0
        Status.last = "Connexion à @$username…"
        ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Status.last = "Connecté à @$username, en attente d’événements"
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                Status.count++
                Status.last = text.take(300)
                try { parse(text, onEvent) } catch (e: Exception) { Status.last = "Erreur : ${e.message} | " + text.take(200) }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Status.last = "Échec de connexion : ${t.message} ${response?.code ?: ""}"
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Status.last = "Connexion fermée ($code) $reason"
            }
        })
    }

    override fun stop() { ws?.close(1000, null); ws = null }

    private fun parse(text: String, out: (LiveEvent) -> Unit) {
        val t = text.trim()
        if (t.startsWith("[")) {
            val a = JSONArray(t)
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { handle(it, out) }
        } else handle(JSONObject(t), out)
    }

    private fun handle(o: JSONObject, out: (LiveEvent) -> Unit) {
        val list = o.optJSONArray("messages")
        if (list != null) {
            for (i in 0 until list.length()) list.optJSONObject(i)?.let { handle(it, out) }
            return
        }
        val type = listOf("type", "event", "messageType", "method")
            .map { o.optString(it) }.firstOrNull { it.isNotBlank() }?.lowercase() ?: return
        val data = o.optJSONObject("data") ?: o
        val user = data.optJSONObject("user") ?: o.optJSONObject("user") ?: return
        val handle = user.optString("uniqueId")
        val name = user.optString("nickname").ifBlank { handle }
        if (name.isBlank()) return
        val avatar = pic(user)
        when {
            "gift" in type -> {
                if (!data.optBoolean("repeatEnd", true)) return
                val g = data.optJSONObject("gift") ?: data
                val gname = g.optString("name").ifBlank { g.optString("giftName") }.ifBlank { "cadeau" }
                val count = maxOf(1, g.optInt("repeatCount", data.optInt("repeatCount", 1)))
                val dia = g.optInt("diamondCount", data.optInt("diamondCount", 0)) * count
                out(LiveEvent("gift", name, handle, avatar, gname, count, dia))
            }
            "follow" in type -> out(LiveEvent("follow", name, handle, avatar))
            "member" in type || "join" in type -> {
                val now = System.currentTimeMillis()
                if (now - lastJoin < 4000) return
                lastJoin = now
                out(LiveEvent("join", name, handle, avatar))
            }
        }
    }

    private fun pic(u: JSONObject): String? {
        for (k in listOf("profilePictureUrl", "avatarUrl", "profilePicture", "avatarThumb", "avatar")) {
            val v = u.opt(k)
            if (v is String && v.startsWith("http")) return v
            if (v is JSONObject) {
                val l = v.optJSONArray("urlList") ?: v.optJSONArray("urls")
                if (l != null && l.length() > 0) return l.optString(0)
                val s = v.optString("url")
                if (s.startsWith("http")) return s
            }
        }
        return null
    }
}
