package com.example.ticketlive

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.util.Locale

class OverlayService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private var web: WebView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var source: LiveSource? = null
    private val main = Handler(Looper.getMainLooper())

    /** Appelé par la page au moment où le ticket commence à s'imprimer : la voix suit le ticket. */
    inner class Bridge {
        @JavascriptInterface
        fun onPrint(json: String) {
            main.post {
                val o = JSONObject(json)
                speak(o.optString("type"), o.optString("name"))
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) { tts?.language = Locale.FRENCH; ttsReady = true }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = NotificationChannel("ticket", "Ticket Live", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "ticket")
            .setContentTitle("Ticket Live actif").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        if (web == null) addOverlay()
        source?.stop()
        val user = intent?.getStringExtra("user").orEmpty()
        val key = intent?.getStringExtra("key").orEmpty()
        source = if (user.isBlank()) DemoSource() else TikTokLiveSource(user, key)
        source!!.start(this::onEvent)
        return START_NOT_STICKY
    }

    private fun addOverlay() {
        val w = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/ticket.html#overlay")
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.6).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP }
        wm.addView(w, lp)
        web = w
    }

    private fun onEvent(e: LiveEvent) {
        main.post { web?.evaluateJavascript("pushEvent(${e.toJson()})", null) }
    }

    private fun speak(type: String, name: String) {
        if (!ttsReady) return
        val text = when (type) {
            "join" -> "Bienvenue $name"
            "follow" -> "Merci pour l’abonnement $name"
            else -> "Merci $name pour le cadeau"
        }
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, null)
    }

    override fun onDestroy() {
        source?.stop()
        web?.let { wm.removeView(it); it.destroy() }
        tts?.shutdown()
        super.onDestroy()
    }
}
