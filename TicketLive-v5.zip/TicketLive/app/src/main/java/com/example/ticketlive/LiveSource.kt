package com.example.ticketlive

import android.os.Handler
import android.os.Looper
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject

data class LiveEvent(
    val type: String,            // "join", "follow" ou "gift"
    val name: String,
    val handle: String,
    val avatar: String? = null,  // URL de la photo de profil (affichée en couleur)
    val gift: String? = null,
    val count: Int = 1,
    val diamonds: Int = 0
) {
    fun toJson(): String = JSONObject()
        .put("type", type).put("name", name).put("handle", handle)
        .put("avatar", avatar ?: JSONObject.NULL).put("gift", gift ?: JSONObject.NULL)
        .put("count", count).put("diamonds", diamonds).toString()
}

interface LiveSource {
    fun start(onEvent: (LiveEvent) -> Unit)
    fun stop()
}

/** État de la connexion, affiché par le bouton « Voir l'état » de l'appli. */
object Status {
    @Volatile var last: String = "Aucune connexion pour l'instant"
    @Volatile var count: Int = 0
    @Volatile var lastEvent: String = "Aucun événement reconnu"
}

/** Faux événements toutes les 7 secondes, pour tester le ticket et la voix. */
class DemoSource : LiveSource {
    private val h = Handler(Looper.getMainLooper())
    private var on = false
    private var cb: ((LiveEvent) -> Unit)? = null
    private val people = listOf("Léa" to "lea_danse", "Karim" to "karim.93", "Mia" to "mia.lounge", "Théo" to "theoplays")
    private val tick = object : Runnable {
        override fun run() {
            if (!on) return
            val (n, u) = people.random()
            cb?.invoke(when ((0..3).random()) {
                0 -> LiveEvent("join", n, u)
                1 -> LiveEvent("follow", n, u)
                2 -> LiveEvent("gift", n, u, null, "Rose", 5, 5)
                else -> LiveEvent("gift", n, u, null, "Lion", 1, 29999)
            })
            h.postDelayed(this, 7000)
        }
    }
    override fun start(onEvent: (LiveEvent) -> Unit) { cb = onEvent; on = true; h.post(tick) }
    override fun stop() { on = false; h.removeCallbacks(tick) }
}

/**
 * Vraie source : WebSocket EulerStream (wss://ws.eulerstream.com).
 * Le format exact des messages n'a pas pu être vérifié : l'analyse ci-dessous est tolérante,
 * et le bouton « Voir l'état » de l'appli affiche le dernier message brut pour l'ajuster au besoin.
 */
class TikTokLiveSource(private val username: String, private val apiKey: String) : LiveSource {
    private var ws: WebSocket? = null
    private val client = OkHttpClient()
    private var lastJoin = 0L
    private var lastLikeAny = 0L
    private val likes = HashMap<String, Pair<Long, Int>>()

    override fun start(onEvent: (LiveEvent) -> Unit) {
        var url = "wss://ws.eulerstream.com?uniqueId=$username"
        if (apiKey.isNotBlank()) url += "&apiKey=$apiKey"
        Status.count = 0
        Status.last = "Connexion à @$username…"
        ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Status.last = "Connecté à @$username, en attente d’événements"
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                Status.count++
                Status.last = text.take(300)
                try { parse(text, onEvent) } catch (e: Exception) { Status.last = "Erreur : ${e.message} | " + text.take(200) }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Status.last = "Échec de connexion : ${t.message} ${response?.code ?: ""}"
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Status.last = "Connexion fermée ($code) $reason"
            }
        })
    }

    override fun stop() { ws?.close(1000, null); ws = null }

    private fun parse(text: String, out: (LiveEvent) -> Unit) {
        val t = text.trim()
        if (t.startsWith("[")) {
            val a = JSONArray(t)
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { handle(it, out) }
        } else handle(JSONObject(t), out)
    }

    private fun handle(o: JSONObject, out: (LiveEvent) -> Unit) {
        val list = o.optJSONArray("messages")
        if (list != null) {
            for (i in 0 until list.length()) list.optJSONObject(i)?.let { handle(it, out) }
            return
        }
        val type = listOf("type", "event", "messageType", "method")
            .map { o.optString(it) }.firstOrNull { it.isNotBlank() }?.lowercase() ?: return
        val data = o.optJSONObject("data") ?: o
        val user = data.optJSONObject("user") ?: o.optJSONObject("user") ?: return
        val handle = user.optString("uniqueId")
        val name = user.optString("nickname").ifBlank { handle }
        if (name.isBlank()) return
        val avatar = pic(user)
        Status.lastEvent = (type + " | avatar=" + (avatar ?: "introuvable") + " | " + o.toString()).take(700)
        when {
            "gift" in type -> {
                if (!data.optBoolean("repeatEnd", true)) return
                val g = data.optJSONObject("gift") ?: data
                val gname = g.optString("name").ifBlank { g.optString("giftName") }.ifBlank { "cadeau" }
                val count = maxOf(1, g.optInt("repeatCount", data.optInt("repeatCount", 1)))
                val dia = g.optInt("diamondCount", data.optInt("diamondCount", 0)) * count
                out(LiveEvent("gift", name, handle, avatar, gname, count, dia))
            }
            "follow" in type -> out(LiveEvent("follow", name, handle, avatar))
            "like" in type -> {
                // Les j'aime arrivent en rafale : on les regroupe (1 ticket max par personne toutes les 20 s,
                // et 1 ticket de j'aime max toutes les 5 s au total).
                val k = handle.ifBlank { name }
                val n = maxOf(1, data.optInt("likeCount", data.optInt("count", 1)))
                val now = System.currentTimeMillis()
                val (last, pending) = likes[k] ?: (0L to 0)
                val total = pending + n
                if (now - last < 20000 || now - lastLikeAny < 5000) { likes[k] = last to total; return }
                likes[k] = now to 0
                lastLikeAny = now
                out(LiveEvent("like", name, handle, avatar, null, total, 0))
            }
            "member" in type || "join" in type -> {
                val now = System.currentTimeMillis()
                if (now - lastJoin < 4000) return
                lastJoin = now
                out(LiveEvent("join", name, handle, avatar))
            }
        }
    }

    private fun pic(root: Any?): String? {
        var best: String? = null
        var bestScore = 0
        fun walk(v: Any?, key: String) {
            when (v) {
                is JSONObject -> v.keys().forEach { walk(v.opt(it), it) }
                is JSONArray -> for (i in 0 until v.length()) walk(v.opt(i), key)
                is String -> if (v.startsWith("http")) {
                    val k = key.lowercase()
                    val u = v.lowercase()
                    val keyHit = listOf("avatar", "profile", "picture", "image", "thumb", "icon").any { it in k }
                    val urlHit = !u.contains(".heic") && listOf("tiktokcdn", "byteimg", "muscdn", ".jpg", ".jpeg", ".png", ".webp").any { it in u }
                    val score = (if (keyHit) 2 else 0) + (if (urlHit) 1 else 0)
                    if (score > bestScore) { best = v; bestScore = score }
                }
            }
        }
        walk(root, "")
        return if (bestScore >= 1) best else null
    }
}
