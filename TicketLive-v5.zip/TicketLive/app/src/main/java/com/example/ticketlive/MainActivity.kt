package com.example.ticketlive

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        val user = EditText(this).apply { hint = "Ton @pseudo TikTok (vide = démo)"; setSingleLine(); setText(prefs.getString("user", "")) }
        val key = EditText(this).apply { hint = "Clé EulerStream (facultatif)"; setSingleLine(); setText(prefs.getString("key", "")) }
        val start = Button(this).apply { text = "Démarrer les tickets" }
        val stop = Button(this).apply { text = "Arrêter" }
        val dbg = Button(this).apply { text = "Voir l’état de la connexion" }
        val info = TextView(this).apply { setPadding(0, pad, 0, 0); setTextIsSelectable(true) }

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Autorise l’affichage par-dessus les autres applis, puis reviens", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            val u = user.text.toString().trim().removePrefix("@")
            val k = key.text.toString().trim()
            prefs.edit().putString("user", u).putString("key", k).apply()
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("user", u).putExtra("key", k))
        }
        stop.setOnClickListener { stopService(Intent(this, OverlayService::class.java)) }
        dbg.setOnClickListener { info.text = "${Status.count} messages reçus\n${Status.last}\n\nDernier événement :\n${Status.lastEvent}" }

        col.addView(TextView(this).apply { text = "Ticket Live"; textSize = 24f })
        col.addView(user); col.addView(key); col.addView(start); col.addView(stop); col.addView(dbg); col.addView(info)
        setContentView(col)
    }
}
