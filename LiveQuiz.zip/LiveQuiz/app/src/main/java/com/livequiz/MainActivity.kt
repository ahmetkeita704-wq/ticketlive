package com.livequiz

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("q", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val user = EditText(this).apply { hint = "Ton pseudo TikTok (sans @)"; setText(p.getString("u", "")) }
        val key = EditText(this).apply { hint = "Clé EulerStream"; setText(p.getString("k", "")) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        root.addView(user)
        root.addView(key)
        root.addView(btn("1. Autoriser l’affichage par-dessus") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("2. Démarrer le quiz") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Fais d’abord l’étape 1", Toast.LENGTH_LONG).show()
            } else {
                p.edit().putString("u", user.text.toString()).putString("k", key.text.toString()).apply()
                startForegroundService(
                    Intent(this, QuizService::class.java)
                        .putExtra("u", user.text.toString())
                        .putExtra("k", key.text.toString())
                )
                Toast.makeText(this, "Quiz lancé : ouvre TikTok et démarre ton live", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(btn("Arrêter") { stopService(Intent(this, QuizService::class.java)) })
        setContentView(root)
    }
}
