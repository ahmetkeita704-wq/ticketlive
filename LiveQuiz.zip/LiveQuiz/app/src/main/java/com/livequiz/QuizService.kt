package com.livequiz

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import okhttp3.*
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

class QuizService : Service() {
    private var wm: WindowManager? = null
    private var web: WebView? = null
    private var tts: TextToSpeech? = null
    private var ws: WebSocket? = null
    private val h = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
    private var user = ""
    private var key = ""
    private var running = false
    private var n = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        user = (i?.getStringExtra("u") ?: "").trim().removePrefix("@")
        key = (i?.getStringExtra("k") ?: "").trim()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("q", "LiveQuiz", NotificationManager.IMPORTANCE_LOW))
        startForeground(
            1,
            Notification.Builder(this, "q").setContentTitle("LiveQuiz actif")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        )
        if (web == null) setup()
        running = true
        connect()
        return START_NOT_STICKY
    }

    private fun setup() {
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRANCE
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) = js("talk(true)")
                    override fun onDone(u: String?) = js("talk(false)")
                    @Deprecated("") override fun onError(u: String?) = js("talk(false)")
                })
            }
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val w = WebView(this)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/quiz.html")
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.62).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP
        wm?.addView(w, lp)
        web = w
    }

    inner class Bridge {
        @JavascriptInterface
        fun speak(t: String) {
            tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u${n++}")
        }
    }

    private fun js(code: String) {
        h.post { web?.evaluateJavascript(code, null) }
    }

    private fun q(s: String) = JSONObject.quote(s)

    private fun connect() {
        if (!running) return
        ws?.cancel()
        val url = "wss://ws.eulerstream.com?uniqueId=" + URLEncoder.encode(user, "UTF-8") +
            "&apiKey=" + URLEncoder.encode(key, "UTF-8")
        ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) = js("setStatus('Connecté ✓')")
            override fun onMessage(w: WebSocket, text: String) = handle(text)
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) = retry()
            override fun onClosed(w: WebSocket, code: Int, reason: String) = retry()
        })
    }

    private fun retry() {
        js("setStatus('Reconnexion…')")
        h.postDelayed({ connect() }, 5000)
    }

    private fun handle(text: String) {
        try {
            val o = JSONObject(text)
            val arr = o.optJSONArray("messages")
            if (arr != null) for (k in 0 until arr.length()) one(arr.getJSONObject(k)) else one(o)
        } catch (e: Exception) {
        }
    }

    private fun one(m: JSONObject) {
        val t = m.optString("type").ifEmpty { m.optString("event") }.lowercase()
        if (!t.contains("chat")) return
        val d = m.optJSONObject("data") ?: m
        val c = d.optString("comment")
        if (c.isEmpty()) return
        val u = d.optJSONObject("user") ?: return
        val id = u.optString("uniqueId")
        val nick = u.optString("nickname").ifEmpty { id }
        js("onChat(${q(id)},${q(nick)},${q(avatar(u))},${q(c)})")
    }

    private fun avatar(u: JSONObject): String {
        var a = u.optString("profilePictureUrl")
        if (!a.startsWith("http")) {
            val p = u.optJSONObject("profilePicture")
            val arr = p?.optJSONArray("urls") ?: p?.optJSONArray("url")
            a = arr?.optString(0) ?: u.optString("profilePicture")
        }
        return if (a.startsWith("http")) a else ""
    }

    override fun onDestroy() {
        running = false
        ws?.cancel()
        tts?.shutdown()
        web?.let { wm?.removeView(it); it.destroy() }
        super.onDestroy()
    }
}
